-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2018 at 03:52 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lpg_sco_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `retailer`
--

CREATE TABLE `retailer` (
  `RETAILER_ID` varchar(10) NOT NULL,
  `NAME` text NOT NULL,
  `DATE_OF_BIRTH` date NOT NULL,
  `PHONE_NUMBER` bigint(20) NOT NULL,
  `SHOP_ADDRESS` varchar(120) NOT NULL,
  `CITY` varchar(20) NOT NULL,
  `STATE` varchar(20) NOT NULL,
  `LISCENCE_NUMBER` varchar(15) NOT NULL,
  `AADHAAR_NUMBER` bigint(20) NOT NULL,
  `LOGIN_USERNAME` text NOT NULL,
  `LOGIN_PASSWORD` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retailer`
--

INSERT INTO `retailer` (`RETAILER_ID`, `NAME`, `DATE_OF_BIRTH`, `PHONE_NUMBER`, `SHOP_ADDRESS`, `CITY`, `STATE`, `LISCENCE_NUMBER`, `AADHAAR_NUMBER`, `LOGIN_USERNAME`, `LOGIN_PASSWORD`) VALUES
('1234123412', 'Rahul Mahanot', '1998-11-30', 8787878788, 'Shahid Nagar', 'Bhubaneswar', 'Orissa', 'A13qw', 123412341234, 'Rahul', 'nanana');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
